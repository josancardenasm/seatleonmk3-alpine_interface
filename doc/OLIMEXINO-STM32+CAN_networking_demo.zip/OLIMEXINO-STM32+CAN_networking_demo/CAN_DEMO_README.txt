|----------------------------------------------------------------------|
|	 README for the CAN DEMO for OLIMEXINO-STM32 + IAR EW 6.30     |
|----------------------------------------------------------------------|

	This project was written, built and tested in
	IAR Embedded Workbench 6.30
	
	The boards that were used -> 3x Olimexino-STM32
	Programmer: J-link for ARM processors + ARM-JTAG-20-10 (from Olimex)
						connector
	
	The boards were connected to each other via CAN interface
	- > CANH to CANH, CANL to CANL, GND to GND
	
	On the CAN bus, there must be two Olimexino-STM32 boards
	with a closed CAN_T jumper. For example, we tested the demo with 3 boards
	and two of them had the CAN_T jumper closed. If there are only two boards
	on the bus, both should have their CAN_T jumper closed.
	
	/--------------------------------------/
	From the Periph. Lib. Example README:
	The CAN serial communication link is a bus to which a number of units 
        may be connected. This number has no theoretical limit. 
        Practically the total number of units will be limited by delay times 
        and/or electrical loads on the bus line.

	@note This example is tested with a bus of 3 units. The same program
        example is loaded in all units to send and receive frames.
	@note Any unit in the CAN bus may play the role of sender 
        (by pressing the BUT button) or receiver.
	/--------------------------------------/
	
	You can find the IAR EW project in:
	CAN_DEMO/EWARM/Project.eww
	
	The peripheral library is included in the /Libraries/ folder and 
	is automatically included in the project
	
	Ths project included in this workspace is configured to program an
	Olimexino-STM32 board with a j-link programmer. All the files have
	already been built, if you change anything, the IDE will only re-build
	the changed files. 
        (!)Do not use project/clean/ as there are some issues 
	   with compiling the startup_stm32f10x_md.s source file. 
	
	In the IAR EW, use Project/Download/Download active application/
	 to download the application to the chip's memory. Alternatively, use 
	the "download & debug" button to download and start a debug session.
	
	After you load the demo on all boards and connect them on a single CAN 
        bus, pressing the BUT button on one board should light up the same LED
        on it and all the other boards on the CAN bus. Pressing the button 
        again should toggle the green and yellow LEDs.
	
	(!)NOTE: Sometimes, after programming a board with j-link, resetting 
        the Olimexino-STM32 is needed for the application to start running
        normally.
	
	If you have any questions, email
	support@olimex.com
	
	OLIMEX, August 2012
	http://www.olimex.com
	
	
	
	