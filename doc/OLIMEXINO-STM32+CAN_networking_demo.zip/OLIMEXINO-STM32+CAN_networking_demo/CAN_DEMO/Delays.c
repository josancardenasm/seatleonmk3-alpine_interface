/*******************************************************************************
* File Name          : Delays.h
* Author             : Olimex
* Version            : 1.0.0
* Date               : 01.08.2012
* Description        : Several functions for Delays for the Olimexino STM32
********************************************************************************/
#include "Delays.h"

#define LOOP_DLY_10US  55

/*************************************************************************
* Function Name: Delay_us
* Parameters: unsigned int delay
*
* Return: none
*
* Description: Delay a given number of microseconds
*
*************************************************************************/
void Delay_10us(unsigned int times)
{
	while(times--)
	{
		for(volatile int i = LOOP_DLY_10US; i; i--);
	}
}

/*************************************************************************
* Function Name: Delayms
* Parameters: unsigned int delay
*
* Return: none
*
* Description: Delay a given number of milliseconds
*
*************************************************************************/
void Delayms(unsigned int delay)
{
  for(int i=0; i<delay; i++)
    Delay_10us(100);
}

