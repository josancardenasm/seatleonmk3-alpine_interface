/*******************************************************************************
* File Name          : Delays.h
* Author             : Olimex
* Version            : 1.0.0
* Date               : 01/08/2012
* Description        : Several functions for Delays for the Olimexino STM32
********************************************************************************/
#ifndef __DELAYS_H
#define __DELAYS_H


/*************************************************************************
* Function Name: Delay_us
* Parameters: unsigned int delay
*
* Return: none
*
* Description: Delay a given number of microseconds
*
*************************************************************************/
void Delay_10us(unsigned int times);


/*************************************************************************
* Function Name: Delayms
* Parameters: unsigned int delay
*
* Return: none
*
* Description: Delay a given number of milliseconds
*
*************************************************************************/
void Delayms(unsigned int delay);

#endif



