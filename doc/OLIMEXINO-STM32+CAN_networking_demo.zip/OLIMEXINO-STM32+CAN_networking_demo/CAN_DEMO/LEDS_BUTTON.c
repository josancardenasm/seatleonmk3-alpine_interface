/*******************************************************************************
* File Name          : LEDS_BUTTON.c
* Author             : Olimex
* Version            : V1.0.0
* Date               : 31/07/2012
* Description        : LEDS_BUTTON Library
********************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include "includes.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* LED Definitions */
#define LED_DELAY_CNT 2000

/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/

/* Private function prototypes -----------------------------------------------*/

/* Private functions ---------------------------------------------------------*/

/*******************************************************************************
* Function Name  : LED_Initialize
* Description    : Initialize LED pins
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void LED_Initialize(void)
{        
	GPIO_InitTypeDef GPIO_InitStructure;
        
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
                
// PA1, PA5 are used by the indicator LEDs on the OLIMEXINO-STM32
/* Configure PA1, PA5 as outputs push-pull, max speed 50 MHz */

	GPIO_InitStructure.GPIO_Pin   = LED1 |  LED2 ;
	GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	
	GPIO_Init(LEDGPIO, &GPIO_InitStructure);		        
}

void BUTTON_Initialize(void)
{  
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOBUTTON, ENABLE);
    GPIO_InitTypeDef GPIO_InitStructure;
// PC9 is used by the button
/* Configure PC9 as floating inputr, max speed 50 MHz */
	GPIO_InitStructure.GPIO_Pin = BOOT0;
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(BUTTONGPIO, &GPIO_InitStructure);
}

/******************* (C) COPYRIGHT 2008 STMicroelectronics *****END OF FILE****/
