/*******************************************************************************
* File Name          : LEDS_BUTTON.h
* Author             : Olimex
* Version            : V1.0.0
* Date               : 31/07/2012
* Description        : Header for the lEDS_BUTTON Library
********************************************************************************
* THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
* WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE TIME.
* AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
* INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE
* CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING
* INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
*******************************************************************************/
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __LEDS_BUTTON_H
#define __LEDS_BUTTON_H

/* Define */

/* Button Definitions */
#define BUTTONGPIO GPIOC
#define RCC_APB2Periph_GPIOBUTTON RCC_APB2Periph_GPIOC
#define BOOT0 	   GPIO_Pin_9
#define BUTTONPIN  GPIO_Pin_9

// TRUE if pressed, FALSE if not
#define GetButton()		(GPIO_ReadInputDataBit(BUTTONGPIO, GPIO_Pin_9) != 0)

/* LED Definitions */
#define LEDGPIO			GPIOA
#define LED1            GPIO_Pin_5
#define LED2            GPIO_Pin_1

#define LED_On(led)     LEDGPIO->ODR |=  led
#define LED_Off(led)    LEDGPIO->ODR &= ~led
#define LED_Toggle(led) LEDGPIO->ODR ^=  led
#define LED_Output(led) LEDGPIO->ODR = (GPIOA->ODR & ~LED_MSK) | led


/*******************************************************************************
* Function Name  : LED_Initialize
* Description    : Initialize LED pins
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void LED_Initialize(void);

/*******************************************************************************
* Function Name  : BUTTON_Initialize
* Description    : Initialize the BUTTON pin
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void BUTTON_Initialize(void);


#endif